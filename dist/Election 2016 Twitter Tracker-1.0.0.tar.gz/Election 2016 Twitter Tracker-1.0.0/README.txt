To run this app:
----------------
1) From the command line, go to the Election2016 (project root) folder.
2) python setup.py install
3) python run.py


